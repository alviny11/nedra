import json
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path
import numpy as np
import pandas as pd
from predictor import Predictor
from api import create_server

ROOT=Path(__file__).resolve().parent

class BundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine=Predictor(ROOT)
        cls.features=pd.read_csv(ROOT/'data'/'predict_features.csv')
        cls.expected=pd.read_csv(ROOT/'data'/'expected_result.csv')

    def test_saved_models_reproduce_all_2000_predictions(self):
        got=pd.DataFrame(self.engine.predict_default())
        self.assertEqual(list(got),['id','segment_id','thickness_pred'])
        pd.testing.assert_frame_equal(got[['id','segment_id']],self.expected[['id','segment_id']])
        np.testing.assert_allclose(got.thickness_pred,self.expected.thickness_pred,atol=1e-6,rtol=0)
        self.assertTrue((got.iloc[:525].id==1250022871).all())
        self.assertTrue((got.iloc[525:].id==1250009583).all())
        self.assertTrue((got.iloc[:525].thickness_pred.to_numpy()<=self.features.iloc[:525].base.to_numpy()).all())

    def test_subset_uses_same_predictions(self):
        got=pd.DataFrame(self.engine.predict_default(case=1,segment_ids=[98,0]))
        exp=self.expected[(self.expected.id==1250022871)&self.expected.segment_id.isin([0,98])].reset_index(drop=True)
        pd.testing.assert_frame_equal(got,exp,check_exact=False,atol=1e-6,rtol=0)

    def test_invalid_requests_are_rejected(self):
        first=self.features.iloc[:1].copy()
        with self.assertRaises(ValueError):self.engine.predict(first.drop(columns=['base']))
        for field,value in [('end','2024-01-01'),('id',1250009583),('segment_id',-1),('base',np.nan),('horizon',0),('base',np.inf)]:
            row=first.copy();row[field]=value
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):self.engine.predict(row)
        with self.assertRaises(ValueError):self.engine.predict(pd.concat([first,first]))
        with self.assertRaises(ValueError):self.engine.predict_default(case=3)
        with self.assertRaises(ValueError):self.engine.predict_default(case=1,segment_ids=[9999])

    def test_custom_rows_and_missing_optional_measurement(self):
        row=self.features.iloc[:1].copy();row['reg_t_mix_mean']=np.nan
        records=json.loads(row.to_json(orient='records'))
        got=self.engine.predict(records)
        self.assertEqual(len(got),1);self.assertTrue(np.isfinite(got[0]['thickness_pred']))

    def test_http_adapter(self):
        server=create_server('127.0.0.1',0,self.engine)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        url=f'http://127.0.0.1:{server.server_port}'
        try:
            with urllib.request.urlopen(url+'/health') as response:
                self.assertEqual(json.load(response)['status'],'ok')
            req=urllib.request.Request(url+'/predict',data=json.dumps({'case':1,'segment_ids':[0,98]}).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req) as response:
                got=json.load(response);self.assertEqual(got['count'],2)
                self.assertEqual(got['predictions'],self.engine.predict_default(case=1,segment_ids=[0,98]))
            bad=urllib.request.Request(url+'/predict',data=b'{"case":3}',headers={'Content-Type':'application/json'})
            with self.assertRaises(urllib.error.HTTPError) as ctx:urllib.request.urlopen(bad)
            self.assertEqual(ctx.exception.code,400)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=3)

if __name__=='__main__':unittest.main()
