"""Small HTTP adapter; Predictor can also be imported into your existing backend."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from predictor import Predictor

def create_server(host='127.0.0.1',port=8000,predictor=None):
    engine=predictor or Predictor()
    class Handler(BaseHTTPRequestHandler):
        def reply(self,status,payload):
            body=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)

        def do_GET(self):
            if self.path=='/health':
                self.reply(200,{'status':'ok','model_version':engine.manifest['version'],'cases':[1,2]})
            else:self.reply(404,{'error':'Not found'})

        def do_POST(self):
            if self.path!='/predict':self.reply(404,{'error':'Not found'});return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<0 or length>8*1024*1024:self.reply(413,{'error':'Request too large'});return
                payload=json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(payload,dict):raise ValueError('Expected a JSON object')
                if 'records' in payload:
                    if set(payload)!={'records'}:raise ValueError('records cannot be combined with other options')
                    if not isinstance(payload['records'],list):raise ValueError('records must be a list')
                    if len(payload['records'])>2000:raise ValueError('At most 2000 rows per request')
                    if any(not isinstance(x,dict) for x in payload['records']):raise ValueError('Each record must be an object')
                    rows=engine.predict(payload['records'])
                else:
                    if set(payload)-{'case','segment_ids'}:raise ValueError('Unknown request options')
                    rows=engine.predict_default(payload.get('case'),payload.get('segment_ids'))
                self.reply(200,{'model_version':engine.manifest['version'],'count':len(rows),'predictions':rows})
            except (ValueError,TypeError,KeyError,OverflowError) as error:
                self.reply(400,{'error':str(error)})
            except Exception:
                self.reply(500,{'error':'Prediction failed; inspect server logs'})
                import traceback;traceback.print_exc()
    return ThreadingHTTPServer((host,port),Handler)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=8000)
    args=parser.parse_args();server=create_server(args.host,args.port)
    print(f'Prediction API on http://{args.host}:{server.server_port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
